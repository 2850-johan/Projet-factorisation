import java.util.Scanner;

import static java.lang.Math.sqrt;

public class Facto {
    public static void main(String[] args)
    {
        int a, b, c;
        // Declarations des solutions
        int x1, x2, x0;
        int discriminant;
        //On entre dans le programme
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entre le coefficient de a:");
        a = scanner.nextInt();
        System.out.println("Entre le coefficient de b:");
        b = scanner.nextInt();
        System.out.println("Entre le coefficient de c:");
        c = scanner.nextInt();

        if (b == 0) {
            System.out.println("on a cette equation:" + a + "x^2 + " + c);
            //  calcul du discriminant
            discriminant = b * b - 4 * a * c;
            //Calcul des solutions en fonction de la valeur du discriminant
            if (discriminant < 0) {
                System.out.println("Ensemble vide");
            } else if (discriminant > 0) {
                //
                x1 = (int) (-b - Math.sqrt(discriminant) / (2 * a));
                x2 = (int) (-b + Math.sqrt(discriminant) / (2 * a));
                System.out.println("On a deux facteurs qui sont : (x+"+x1+")(x-"+x2+")");
            } else {
                x0 = -b / (2 * a);
                System.out.println("L'unique solution est x0=" + x0);
            }

        }
    }
}
